package p05_PizzaCalories;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Main {
    static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    static List<Dough> doughList = new ArrayList<>();
    static Pizza pizza;
    static String pizzaName;
    static int number = 0;

    public static void main(String[] args) throws IOException {
        Locale.setDefault(Locale.ROOT);

        try {
            String[] input = reader.readLine().split("[\\s]+");
            while (!input[0].equals("END")) {
                String caller = input[0];
                switch (caller) {
                    case "Pizza":
                        pizzaName = input[1];
                        number = Integer.valueOf(input[2]);
                        checkToppings(number);
                        break;
                    case "Dough": makeDough(input); makePizza(); break;
                    case "Topping": makeTopping(input); break;
                }
                input = reader.readLine().split("[\\s]+");
            }

            pizza.getPrintOut();

        } catch (IllegalArgumentException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private static void checkToppings(int number) {
        if (number > 10) {
            throw new IllegalArgumentException("Number of toppings should be in range [0..10].");
        }
    }

    private static void makePizza() {
        pizza = new Pizza(pizzaName, doughList.get(0));
    }

    private static void makeTopping(String[] input)  {
            String toppingType = input[1];
            Double weight = Double.valueOf(input[2]);
            Topping topping = new Topping(toppingType, weight, pizza);
            topping.addToppings(topping);
    }

    private static void makeDough(String[] input) {
        String doughType = input[1];
        String technique = input[2];
        Double weight = Double.valueOf(input[3]);
        Dough dough = new Dough(doughType, technique, weight);
        doughList.add(dough);
    }
}
